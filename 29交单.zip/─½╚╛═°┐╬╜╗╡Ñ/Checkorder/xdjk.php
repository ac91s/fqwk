<?php  

function wkname()
{
	$data = array(
	    "mylover" => "mylover",
	    "daxiong" => "大雄学习平台",
	    "29" => "29同系统", 
	    "27" => "27", 
	    "dandan" => "蛋蛋",
	    "ikunzjy" => "ikun职教云",
	    "mylover" => "mylover",
	    "ylck" => "一流ck", 
	    "gsl2.0" => "哥斯拉2.0", 
	    "kingck" => "king ck 只支持查课下单", 
	    "king" => "king token 只支持查课下单",
	    "lyj" => "老友记类型", 
	    "oligei" => "oligei", 
	    "ikunzjy" => "ikun职教云", 
	    /*"wklmtoken" => "网课联盟token", 
	    "wklmcookie" => "网课联盟cookie",
	    "00" => "00",
	    "jz" => "捐赠接口",
	    "xxtgf" => "学习通(官方查课)",
	    "zjygf" => "智慧职教职教云(官方查课)",
	    "moocgf" => "智慧职教MOOC(官方查课)",
	    "zykgf" => "智慧职教资源库(官方查课)",
	    "ayck"=>"ay查课插件调用查课",
	    "dlam"=>"哆啦a梦cookie",*/
	    );
	return $data;
}
// 这里也要添加相应的接口数据  比如  "shenwei" => "神威",  后他设置里面才能看到

function addWk($oid){
	global $DB;
	global $wk;
	$d = $DB->get_row("select * from qingka_wangke_order where oid='{$oid}' ");
	$cid = $d["cid"];
	$school = $d["school"];
	$user = $d["user"];
	$pass = $d["pass"];
	$kcid = $d["kcid"];
	$kcname = $d["kcname"];
	$noun = $d["noun"];
	$miaoshua = $d["miaoshua"];
	$b = $DB->get_row("select * from qingka_wangke_class where cid='{$cid}' ");
	$hid = $b["docking"];
	$a = $DB->get_row("select * from qingka_wangke_huoyuan where hid='{$hid}' ");
	$type = $a["pt"];
	$cookie = $a["cookie"];
	$token = $a["token"];
	$ip = $a["ip"];
	
	/*****
	 自己可以根据规则增加下单接口    
	 
	//XXXX下单接口
	else if ($type == "XXXX") {
	$data = array("optoken" => $token,"type" => $noun);  请求体参数自己加
	$XXXX_ul = $a["url"];      变量XXXX自己命名    获取顶级域名
	$XXXX_dingdan = "http://$XXXX_ul/api/CourseQuery/api/";    请求接口   XXXX自己命名
	$result = get_url($XXXX_dingdan, $data, $cookie); 
	$result = json_decode($result, true);
	
	if ($result["code"] == "0") {
		$b = array("code" => 1, "msg" => $result["msg"]);
	} else {
		$b = array("code" => -1, "msg" => $result["msg"]);
	}
	return $b;
    }
	
	
	$token  传的token
	$school  传的学校
	$user    传的账号
	$pass    传的密码
	$noun    传的平台里面的接口编号 
	$kcid    传的课程id
	****/ 
	
 
	
	//27下单接口
    if ($type == "27") {
		$data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname);
		$eq_rl = $a["url"];
		$eq_url = "$eq_rl/api.php?act=add";
		$result = get_url($eq_url, $data,$cookie);
		$result = json_decode($result, true);
		if ($result["code"] == "0") {
			$b = array("code" => 1, "msg" => "下单成功");
		} else {
			$b = array("code" => -1, "msg" => $result["msg"]);
		}
		return $b;}
		//可达鸭下单
	else if ($type == "mylover") {
$data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user"
=>$user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
$dx_rl = $a["url"];
$dx_url = "$dx_rl/api.php?act=add";
$result = get_url($dx_url, $data);
$result = json_decode($result, true);
if ($result["code"] == "0") {
$b = array("code" => 1, "msg" => "下单成功");
} else {
$b = array("code" => -1, "msg" => $result["msg"]);
}
return $b;
}
	 //ikunzjy下单接口
    else if ($type == "ikunzjy") {
    	$ikun_surl = $a["url"];
        $ikun_url = $ikun_surl."/api/ikunzjy.php?act=xd&token=".$token."&platform=".$noun."&school=".$school."&account=".$user."&password=".$pass."&course=".$kcname."";
        $result =get_url($ikun_url); 
        $result = json_decode($result, true);  
		if ($result["code"] == "1") {
			$b = array("code" => 1, "msg" => $result["msg"],"yid"=>$result["order_token"]);
		} else {
			$b = array("code" => -1, "msg" => $result["msg"]);
		}
		return $b;
    } 
//老友下单
else if ($type == "lyj") {
    $data = array("token" => $a["token"], "platform" => $noun, "school" => $school, "account" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
    $lyj_rl = $a["url"];
    $lyj_url = "$lyj_rl/api/coursesub.php";
    $result = get_url($lyj_url, $data);
    $result = json_decode($result, true);
    if ($result["code"] == "0") {
        $b = array("code" => 1, "msg" => "下单成功");
    } else {
        $b = array("code" => -1, "msg" => $result["msg"]);
    }
    return $b;} 
		//king ck下单接口
	else if($type == "kingck"){
       $data[] = array("PlatformID" => $noun, "school"=>$school,"list"=>array($kcname), "username" => $user,"password" => $pass,"isUnit" => false,"miao" => false); 
       $data=json_encode($data,true);
       $king_surl = $a["url"];
       $king_url = "$king_surl/api/Order/GiveClass";
       $header = [
           "Content-Type:application/json;charset=utf-8",
           "Origin: {$a["url"]}",
	    	"x-requested-with:XMLHttpRequest",
           ];
       $result = get_url3($king_url,$data,$cookie,$header); 
       $result = json_decode($result, true);  
        if ($result["msg"] == "已经秒上号"){
            $b = ["code" => 1, 'msg' => $result["msg"]];
        }else{
            $b = ["code" => -1, 'msg' => $result["msg"]];
      }
    return $b;}
		//蛋蛋下单代码
    else if($type == "dandan"){
	    $data = array("accountmsg" => [["$school $user $pass","$kcname"]],"token" => $token,"value" => $noun); 
	   	$data=json_encode($data);
	   	$header = ["Content-Type:application/json;charset=UTF-8",];
	   	$ll_surl = $a["url"];
        $ll_url = "$ll_surl/order/submit/";
	    $result = post($ll_url,$data,$header); 
	    $result = json_decode($result, true); 
    	if ($result["code"] == 0) {
    			$b = array("code" => 1, "msg" => $result["msg"][0]);
    	} else {
    		$b = array("code" => -1, "msg" => $result["msg"][0]);
    	}
    	return $b;
	}
	//哥斯拉2.0下单接口
	else if ($type == "gsl2.0") {
		$data = array("Token" => $token, "plat" => $noun, "school" => $school, "username" => $user, "password" => $pass, "name" => $kcname, "mode" => "1");
		$gsl_rl = $a["url"];
		$gsl_url = "$gsl_rl/api/unionApi/simple";
		$result = get_url($gsl_url, $data);
		$result = json_decode($result, true);
		if ($result["code"] == "0") {
		    $yid1=$result["course_trade_ids"];
		    $first = array_shift($yid1);
			$b = array("code" => 1, "msg" => $result["msg"],"yid" => $first);
		
		} else {
			$b = array("code" => -1, "msg" => $result["msg"]);
		}
		return $b;} 
	//一流ck下单接口
    else if ($type == "ylck") {
		$data = array("cid" => $noun, "data[0][userinfo]" => "$school $user $pass","data[0][check_row][0][id]" => $kcid,"data[0][check_row][0][name]" => $kcname,"data[0][code]" => 1);
		$yl_rl = $a["url"];
		$yl_url = "$yl_rl/api/ajax.php?act=addwk";
		$header = ["token:$token",];
		$result = post($yl_url,$data,$header); 
		$result = json_decode($result, true);
		if ($result["code"] == "1") {
			$b = array("code" => 1, "msg" => $result["msg"]);
		} else {
			$b = array("code" => -1, "msg" => $result["msg"]);
		}
		return $b;} 
		//大雄学习平台下单接口 放在/Checkorder/xdjk.php 文件
else if ($type == "daxiong") {
$data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
$dx_rl = $a["url"];
$dx_url = "$dx_rl/api.php?act=add";
$result = get_url($dx_url, $data);
$result = json_decode($result, true);
if ($result["code"] == "0") {
$b = array("code" => 1, "msg" => "下单成功");
} else {
$b = array("code" => -1, "msg" => $result["msg"]);
}
return $b;} 
//29同系统接口
else if ($type == "29") {
$data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
$dx_rl = $a["url"];
$dx_url = "$dx_rl/api.php?act=add";
$result = get_url($dx_url, $data);
$result = json_decode($result, true);
if ($result["code"] == "0") {
$b = array("code" => 1, "msg" => "下单成功");
} else {
$b = array("code" => -1, "msg" => $result["msg"]);
}
return $b;} 
	//欧巴下单接口	
	else if ($type == "ouba") {
	    $data = array("optoken" => $token, "type" => $noun,"task" => 3,"school" => $school, "account" =>$user, "pwd" =>$pass, "courseName" =>$kcname, "num" =>1      );
     	$ouba_ul = $a["url"];
		$ouba_dingdan = "$ouba_ul/Openapi/submitCourse.jsp"; 
		$result = get_url($ouba_dingdan, $data, $cookie);
		$result = json_decode($result, true);
		if ($result["code"] == 0) {
			$b = array("code" => 1, "msg" => "添加成功");
		} else {
			$b = array("code" => -1, "msg" => $result["message"]);
		}
		return $b;} 
	//wklmcookie下单接口
	else if($type == "wklmcookie") {
	    $data = array("row[courses_id]_text"=>"","row[courses_id]" =>$noun, "row[school]" => $school, "row[studentnumber]" =>$user, "row[studentpwd]" =>$pass,"courseids" =>$kcid,"row[name]" =>$kcname,"row[accountinfo]"=>"考试","row[hour]"=> 0);
     	$wklm = $a["url"];
		$wklm_dingdan = "$wklm/orderrecord/add?dialog=1";
		$header = ["X-Requested-With:XMLHttpRequest"];
		$result = get_url($wklm_dingdan, $data, $cookie,$header);  
		$result = json_decode($result, true);
      	if ($result["code"] == 1) {
			$b = array("code" => 1, "msg" => "添加成功");
		} else {
			$b = array("code" => -1, "msg" => $result["message"]);
		}
		return $b;}
	//00下单接口
	else if($type == "00"){
	    $data = array("school"=>$school,"account"=>$user,"password"=>$pass,"coursename"=>$kcname,"value"=>$noun,"token"=> $token);
	$ll_ul = $a["url"];
	$ll_dingdan = "$ll_ul/submit";
	$result = get_url($ll_dingdan, $data, $cookie);
	$result = json_decode($result, true);
	if ($result["code"] == 0) {
		$b = array("code" => 1, "msg" => "添加成功");
	} else {
		$b = array("code" => -1, "msg" => $result["message"]);
	}
	return $b;}
	//wklmtoken下单接口	
	else if($type == "wklmtoken") {
	    $wklm_surl = $a["url"];
	    $token = $a['token'];
        $std_name = $d['user'];
        $std_pwd = $d['pass'];
        $std_school = $d['school'];
        $ptid = $noun;
        $course_name= $d['kcname'];
        $is_exam = 1;
	    if(json_decode(file_get_contents("$wklm_surl/api/batch?token=".$token."&std_name=".$std_name."&std_pwd=".$std_pwd."&std_school=".$std_school."&ptid=".$ptid."&course_name=".$course_name."&is_exam=".$is_exam),true)['code']==200){
            	$b = array("code" => 1, "msg" => "添加成功");
        	} else {
        		$b = array("code" => -1, "msg" => "发生错误");
        	}
        return $b;
	}
	 //oligei下单接口
   else if ($type == "oligei") {
  $data = array( "token" => $token,"ptid" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid, "miaoshua" => $miaoshua, "shichang" => $shichang);
  $oligei_rl = $a["url"];
  $oligei_url = "$oligei_rl/api/add";
  $result = get_url($oligei_url, $data,$cookie);
  $result = json_decode($result, true);
  if ($result["code"] == "0") {
   $b = array("code" => 1, "msg" => "下单成功");
  } else {
   $b = array("code" => -1, "msg" => $result["msg"]);
  }
  return $b;}
	else{
	    print_r("没有了,文件xdjk.php,可能故障：参数缺少，比如平台名错误！！！");die;
	
	}
	
}


?>