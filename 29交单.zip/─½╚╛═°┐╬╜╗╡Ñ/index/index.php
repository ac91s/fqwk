<?php
include('header.php');

?>
<script src="assets/js/bootstrap.min.js"></script>
<body class="layui-layout-body">
  
  <div id="LAY_app">
    <div class="layui-layout layui-layout-admin">
      <div class="layui-header">
        <!-- 头部区域 -->
        
        <ul class="layui-nav layui-layout-left">
          <li class="layui-nav-item layadmin-flexible" lay-unselect>
            <a href="javascript:;" layadmin-event="flexible" title="侧边伸缩">
              <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
            </a>
          </li>
         
          <li class="layui-nav-item" lay-unselect>
            <a href="javascript:;" layadmin-event="refresh" title="刷新">
              <i class="layui-icon layui-icon-refresh-3"></i>
            </a>
          </li>
         <?php if($userrow['vip']==1){
    $isMobile = false;
    if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/(android|iphone|ipad|ipod)/i', $_SERVER['HTTP_USER_AGENT'])) {
        $isMobile = true;
    }
?>
    <li class="layui-nav-item" lay-unselect>
        <img src="../logo.png" width="30px">
        <?php if ($isMobile) { ?>
            <span style="display: none;">尊贵的会员欢迎登录</span>
        <?php } else { ?>
            <span style="color: black;">尊贵的会员欢迎登录</span>
        <?php } ?>
    </li>
<?php } ?>

          
          
          
          
        </ul>
        <ul class="layui-nav layui-layout-right" lay-filter="layadmin-layout-right">
          <!--<li class="layui-nav-item" lay-unselect>-->
          <!--  <a lay-href="app/message/index.html" layadmin-event="message" lay-text="消息中心">-->
          <!--    <i class="layui-icon layui-icon-notice"></i>-->
      
              <!-- 如果有新消息，则显示小圆点 -->
            <!--  <span class="layui-badge-dot"></span>-->
            <!--</a>-->
          <!--</li>-->
          
          <!--<li class="layui-nav-item layui-hide-xs" lay-unselect>-->
          <!--  <a href="javascript:;"  title="小储对接商城">-->
          <!--    <i class="layui-icon layui-icon-cart"></i>-->
          <!--     站长小储对接商城：<?=$conf['zzqq']?>-->
          <!--  </a>-->
          <!--</li>-->
          <!-- <li class="layui-nav-item layui-hide-xs" lay-unselect>-->
          <!--  <a href="https://zxsc.pro/" target="_blank" title="小洛商城">-->
          <!--    <i class="layui-icon layui-icon-chart-screen"></i>-->
          <!--    小储交单平台https://zxsc.pro/-->
          <!--  </a>-->
          <!--</li>-->
          <!--<li class="layui-nav-item layui-hide-xs" lay-unselect>-->
          <!--  <a href="javascript:;" title="微信">-->
          <!--    <i class="layui-icon layui-icon-login-wechat"></i>-->
          <!--     站长联系方式2：<?=$conf['zzvx']?>-->
          <!--  </a>-->
          <!--</li>-->
          <!--<li class="layui-nav-item layui-hide-xs" lay-unselect>-->
          <!--  <a href="" target="_blank" title="Roois商城">-->
          <!--    <i class="layui-icon layui-icon-cart"></i> 官方商城-->
          <!--  </a>-->
          <!--</li>-->
          <!--<li class="layui-nav-item layui-hide-xs" lay-unselect>-->
          <!--<a href="javascript:;" layadmin-event="note">-->
          <!--   <i class="layui-icon layui-icon-note"></i>-->
          <!--  </a>-->
          <!--</li>-->
         
          <li class="layui-nav-item" lay-unselect>
            <a href="javascript:;">
                <img class="img-avatar img-avatar-48 m-r-10" style="border-radius: 6px;width:30px;height:30px;border:0px;" src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" >
                  
              <cite><?php echo $userrow['user']?></cite>
            </a>
            <dl class="layui-nav-child">
                <?php if ($conf['sjqykg']==1) {?>
              <dd><a id="sjqy"><i class=" layui-icon layui-icon-upload-drag"></i> 上级迁移</a></dd>
              <hr>
              <?}?>
              <dd><a lay-href="passwd"><i class=" layui-icon layui-icon-auz"></i> 修改密码</a></dd>
              <hr>
              <dd style="text-align: center;"><a href="../apisub.php?act=logout"><i class="layui-icon layui-icon-close-fill"></i>退出</a></dd>
            </dl>
          </li>
           <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="javascript:" layadmin-event="theme">
                        <i class="layui-icon layui-icon-theme"></i>
                    </a>
                </li>
       <li class="layui-nav-item layui-hide-xs" lay-unselect>
            <a href="javascript:;" layadmin-event="fullscreen" title="全屏">
              <i class="layui-icon layui-icon-screen-full"></i>
            </a>
          </li>
          <li class="layui-nav-item layui-hide-xs" lay-unselect>
            <a href="javascript:;" layadmin-event="about"><i class="layui-icon layui-icon-more-vertical"></i></a>
          </li>
          <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-unselect>
            <a href="javascript:;" layadmin-event="more" ><i class="layui-icon layui-icon-more-vertical"></i></a>
          </li>
        </ul>
      </div>
     
      <!-- 侧边菜单 -->
      <div class="layui-side layui-side-menu">
        <div class="layui-side-scroll">
          <div class="layui-logo" lay-href="home/console.html">
            <span><?=$conf['sitename']?></span>
          </div>



          <ul class="layui-nav layui-nav-tree" lay-filter="test" id="LAY-system-side-menu"
            lay-filter="layadmin-system-side-menu">
              
            <li data-name="home" class="layui-nav-item layui-nav-itemed">
              <a href="index" lay-tips="主页" lay-direction="2">
                <i class="layui-icon layui-icon-home"></i>
                <cite>主页</cite>
              </a>
            </li>
            
            <?php if($userrow['uid']==1){ ?>
                <li data-name="set" class="layui-nav-item">
                  <a href="javascript:;" lay-tips="设置" lay-direction="2">
                    <i class="layui-icon layui-icon-set"></i>
                    <cite>设置</cite>
                  </a>
                  <dl class="layui-nav-child">
                    <dd data-name="console" class="layui-this">
                      <a lay-href="webset" >系统设置</a>
                    </dd>
                    <!--<dd data-name="console">-->
                    <!-- <a lay-href="add2">测试11111111</a>-->
                    <!--</dd>-->
                    <dd data-name="console">
                     <a lay-href="gonggao">公告设置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="huoyuan">接口配置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="class">网课设置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="fenlei">分类设置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="dengji">等级设置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="mijia">密价设置</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="paylist">支付订单</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="data">今日数据</a>
                    </dd>
                    <dd data-name="console">
                      <a lay-href="guanx">卡密数据</a>
                      </dd>
                  </dl>
                </li>
            <?php } ?>
            
     
   
           
            <li data-name="user" class="layui-nav-item layui-nav-itemed">
              <a href="javascript:;" lay-tips="学习中心" lay-direction="2">
                <i class="layui-icon layui-icon-username"></i>
                <cite>学习中心</cite>
              </a>
              <dl class="layui-nav-child">
                <dd>
                    
                <i class="layui-icon layui-icon-add-circle"></i>  <a lay-href="add2" >立即学习</a>
                </dd>
                <dd>
                <i class="layui-icon layui-icon-form" ></i><a lay-href="list2">学习列表</a>
                </dd>
                <dd>
                <i class="layui-icon layui-icon-cart-simple" ></i><a lay-href="myprice">学习价格</a>
                </dd>
                
                
              
                
                </li>
                 
            
             <li data-name="user" class="layui-nav-item">
              <a href="javascript:;" lay-tips="便捷操作" lay-direction="2">
                <i class="layui-icon layui-icon-set"></i>
                <cite>强国接码</cite>
              </a>
              <dl class="layui-nav-child">
                <dd>
                <a href="http://yz.hhxxone.cn/remotelogin_xxqg_self/login/" >强国接码<span class="layui-btn layui-btn-xs layui-btn-normal">哆啦强国</span></a>
                </dd>
                <dd>
                <a href="http://code.52ax.vip" >强国接码<span class="layui-btn layui-btn-xs layui-btn-normal">爱学强国</span></a>
                </dd>
              </dl>
            </li>
           
           
           
           
           
           
           
             <li data-name="user" class="layui-nav-item">
              <a href="javascript:;" lay-tips="编辑内容" lay-direction="2">
                <i class="layui-icon layui-icon-set"></i>
                <cite>编辑内容</cite>
              </a>
              <dl class="layui-nav-child">
                   <dd>
              <!--<li class="nav-item nav-item-has-subnav">-->
              <!--<a href="javascript:void(0)"><i class="mdi mdi-file-document-box"></i> <span>编辑内容</span></a>-->
              <ul class="nav nav-subnav">
                 <li> <a class="multitabs" href="bjlw">论文编辑</a> </li>
                <li> <a class="multitabs" href="bjkt">开题编辑</a> </li>
                <li> <a class="multitabs" href="bjyj">月记编辑</a> </li>
                <li> <a class="multitabs" href="bjzj">周记编辑</a> </li>
                <li> <a class="multitabs" href="bjrj">日记编辑</a> </li>
               
              </ul>
            </li>
           
           
           
           
           
            
           <li data-name="user" class="layui-nav-item">
              <a href="javascript:;" lay-tips="余额充值" lay-direction="2">
                <i class="layui-icon layui-icon-rmb"></i>
                <cite>余额充值</cite>
              </a>
              <dl class="layui-nav-child">
                <dd>
                <i class="layui-icon layui-icon-add-circle"></i>  <a lay-href="charge" >在线充值</a>
                </dd>
                <dd>
                <i class="layui-icon layui-icon-form" ></i><a lay-href="pay">卡密充值</a>
                </dd>
             
              </dl>
            </li>
            
            <!--<li data-name="list2" class="layui-nav-item">-->
            <!--            <a lay-href="list2" lay-text="学习列表" lay-tips="学习列表" lay-direction="3">-->
            <!--                <i class="layui-icon layui-icon-form" ></i>-->
            <!--                <cite>学习列表</cite>-->
            <!--            </a>-->
            <!--        </li>-->
            <li data-name="userlist" class="layui-nav-item">
                        <a lay-href="userlist" lay-text="下级管理" lay-tips="下级管理" lay-direction="3">
                            <i class="layui-icon layui-icon-user" ></i>
                            <cite>下级管理</cite>
                        </a>
                    </li>
                    
            
            <!--<li data-name="app" class="layui-nav-item">-->
            <!--  <a href="javascript:;" lay-tips="学习课程" lay-direction="2">-->
            <!--    <i class="layui-icon layui-icon-release"></i>-->
            <!--    <cite>在线学习</cite>-->
            <!--  </a>-->
            <!--  <dl class="layui-nav-child">-->
              <!--  <dd>-->
              <!--    <a lay-href="add">单个提交</a>-->
              <!--  </dd>-->
                <!--<dd>-->
                <!--  <a lay-href="add_pl">批量提交</a>-->
                <!--</dd>-->
            <!--    <dd>-->
            <!--      <a lay-href="add2">任务提交</a>-->
            <!--    </dd>-->
                
            <!--    <dd>-->
            <!--      <a lay-href="list2">学习列表</a>-->
            <!--    </dd>-->
                
            <!--    <dd>-->
            <!--      <a lay-href="myprice">学习价格</a>-->
            <!--    </dd>-->
                <!--<dd>-->
                <!--  <a lay-href="add_pt">批量提交</a>-->
                <!--</dd>-->
            <!--  </dl>-->
            <!--</li>-->
            <!--<li data-name="myprice" class="layui-nav-item">-->
            <!--            <a lay-href="myprice" lay-text="学习价格" lay-tips="学习价格" lay-direction="3">-->
            <!--                <i class="layui-icon layui-icon-cart-simple" ></i>-->
            <!--                <cite>学习价格</cite>-->
            <!--            </a>-->
            <!--        </li>-->
            
            <li data-name="workorder" class="layui-nav-item">
                        <a lay-href="workorder" lay-text="提交工单" lay-tips="提交工单" lay-direction="3">
                            <i class="layui-icon layui-icon-service" ></i>
                            <cite>提交工单</cite>
                        </a>
                    </li>
                    
                                <?php if($userrow['uid']==1){ ?>
           
             <li data-name="charge" class="layui-nav-item">
                        <a lay-href="log" lay-text="操作日志" lay-tips="操作日志" lay-direction="3">
                            <i class="layui-icon layui-icon-rmb" ></i>
                            <cite>操作日志</cite>
                        </a>
                    </li>
                    <?php }?>
                   
            <!--<?php if($userrow['uuid']!=1){ ?>-->
            <!--<li data-name="pay" class="layui-nav-item">-->
            <!--            <a lay-href="charge" lay-text="我要充值" lay-tips="我要充值" lay-direction="3">-->
            <!--                <i class="layui-icon layui-icon-rmb" ></i>-->
            <!--                <cite>我要充值</cite>-->
            <!--            </a>-->
            <!--        </li>-->
            <!--<?php } ?>-->
            <li data-name="user" class="layui-nav-item">
              <a href="javascript:;" lay-tips="个人管理" lay-direction="2">
                <i class="layui-icon layui-icon-username"></i>
                <cite>个人管理</cite>
              </a>
              <dl class="layui-nav-child">
                  <dd>
                <dd>
                    <a class="multitabs" id="sjqy">上级迁移</a>
                </dd>
                <dd>
                  <a lay-href="passwd">修改密码</a>
                </dd>
                
                <!--<dd>-->
                <!--  <a lay-href="myprice">价格列表</a>-->
                <!--</dd>-->
                <!--<dd>-->
                <!--  <a lay-href="weiyu">站长微语</a>-->
                <!--</dd>-->
              </dl>
            </li>
            <!--<li data-name="userlist"  class="layui-nav-item">-->
            <!--    <a href="javascript:;" lay-tips="代理管理" lay-direction="2">-->
            <!--        <i class="layui-icon layui-icon-user"></i><cite>代理管理</cite> -->
            <!--   </a>-->
            <!--   <dl class="layui-nav-child">-->
            <!--    <dd>-->
            <!--      <a lay-href="userlist">我的代理</a>-->
            <!--    </dd>-->
                
            <!--</li>-->
            <!--<li data-name="user" class="layui-nav-item">-->
            <!--  <a href="javascript:;" lay-tips="学习任务" lay-direction="2">-->
            <!--    <i class="layui-icon layui-icon-survey"></i>-->
            <!--    <cite>学习任务</cite>-->
            <!--  </a>-->
            <!--  <dl class="layui-nav-child">-->
                <!--<dd>-->
                <!--  <a lay-href="help">帮助中心</a>-->
                <!--</dd>-->
            <!--  </dl>-->
            <!--</li>-->
            
            <li data-name="user" class="layui-nav-item">
              <a href="javascript:;" lay-tips="其他管理" lay-direction="2">
                <i class="layui-icon layui-icon-app"></i>
                <cite>其他管理</cite>
              </a>
              <dl class="layui-nav-child">
                <dd>
                  <a lay-href="docking">平台对接</a>
                </dd>
                <dd>
                  <a lay-href="help">课程说明</a>
                </dd>
                
              </dl>
            </li>
           
            
            <!--<li data-name="user" class="layui-nav-item">-->
            <!--  <a href="javascript:;" lay-tips=”其他管理“ lay-direction="2">-->
            <!--    <i class="layui-icon layui-icon-log"></i>-->
            <!--    <cite>其他管理</cite>-->
            <!--  </a>-->
            <!--  <dl class="layui-nav-child">-->
                
                
            <!--    <dd>-->
            <!--      <a lay-href="help">课程说明</a>-->
            <!--    </dd>-->
                
            <!--  </dl>-->
            <!--</li>-->
            
            
            <!-- <li data-name="chart" class="layui-nav-item">-->
            <!--  <a lay-href="help" lay-tips="课程说明" lay-direction="2">-->
            <!--    <i class="layui-icon layui-icon-about"></i>-->
            <!--    <cite>课程说明</cite>-->
            <!--  </a>-->
            <!--</li>-->
            
             <li data-name="logout" class="layui-nav-item">
              <a href="../apisub.php?act=logout" lay-tips="退出登录" lay-direction="2">
                <i class="layui-icon layui-icon-close-fill"></i>
                  
                     <cite>退出登录</cite></a> </li>
          </ul>
        </div>
      </div>

      <!-- 页面标签 -->
      <div class="layadmin-pagetabs" id="LAY_app_tabs">
        <div class="layui-icon layadmin-tabs-control layui-icon-prev" layadmin-event="leftPage"></div>
        <div class="layui-icon layadmin-tabs-control layui-icon-next" layadmin-event="rightPage"></div>
        <div class="layui-icon layadmin-tabs-control layui-icon-down">
          <ul class="layui-nav layadmin-tabs-select" lay-filter="layadmin-pagetabs-nav">
            <li class="layui-nav-item" lay-unselect>
              <a href="javascript:;"></a>
              <dl class="layui-nav-child layui-anim-fadein">
                <dd layadmin-event="closeThisTabs"><a href="javascript:;">关闭当前标签页</a></dd>
                <dd layadmin-event="closeOtherTabs"><a href="javascript:;">关闭其它标签页</a></dd>
                <dd layadmin-event="closeAllTabs"><a href="javascript:;">关闭全部标签页</a></dd>
              </dl>
            </li>
          </ul>
        </div>
        <div class="layui-tab" lay-unauto lay-allowClose="true" lay-filter="layadmin-layout-tabs">
          <ul class="layui-tab-title" id="LAY_app_tabsheader">
            <li lay-id="home/console.html" lay-attr="home/console.html" class="layui-this"><i class="layui-icon layui-icon-home"></i></li>
          </ul>
        </div>
      </div>
      
      
      <!-- 主体内容 -->
      <div class="layui-body" id="LAY_app_body">
        <div class="layadmin-tabsbody-item layui-show">
          <iframe src="main" frameborder="0" class="layadmin-iframe"></iframe>
        </div>
      </div>
      
      <!-- 辅助元素，一般用于移动设备下遮罩 -->
      <div class="layadmin-body-shade" layadmin-event="shade"></div>
    </div>
  </div>

  <script src="/index/assets/js/shuiyin.js"></script>
  <!--<script src="assets/layuiadmin/layui/layui.js"></script>-->
  <?php if ($conf['sykg']==1) {?>
  <script>
  watermark('<?=$conf['sitename'];?>','账号 : <?=$userrow['uid'];?>','截图封号');
  </script>
  <?}?>

  <script>
  
    layui.config({
    base: './assets/layuiadmin/' //静态资源所在路径
  }).extend({
    index: 'lib/index' //主入口模块
  }).use('index');
   $('#sjqy').click(function() {
            layer.prompt({title: '请输入要转移的上级UID', formType: 3}, function(uid, index){
			  layer.close(index);
	           layer.prompt({title: '请输入要转移的上级邀请码', formType: 3}, function(yqm, index){
			  layer.close(index);
	           var load=layer.load();
	           $.ajax({
	               type: "POST",
	               url: "../apisub.php?act=sjqy",
	               data: {"uid":uid,"yqm":yqm},
	               dataType: 'json',
	               success: function(data) {
	                   layer.close(load);
	                   if (data.code == 1) {
	                       layer.msg(data.msg,{icon:1});
	                   } else {
	                       layer.msg(data.msg,{icon:2});
	                   }
	               }
	           });           
		  });           
		  });		
    });
  </script>
<script charset="UTF-8" id="LA_COLLECT" src="//sdk.51.la/js-sdk-pro.min.js?id=Jn7D2bUCe2U5jXJk&ck=Jn7D2bUCe2U5jXJk"></script>
   <script type="text/javascript">
</script>

</body>
</html>