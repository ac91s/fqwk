<?php
$title='公告设置';
require_once('header.php');
if($userrow['uid']!=1){
	alert("你来错地方了","index.php");
}
?>
<div class="layui-fluid" id="LAY-component-grid-mobile-pc">
  <div class="layui-row layui-col-space10">
    <div class="layui-col-xs12 layui-col-md12">
      <!-- 填充内容 -->
      <div class="layui-card">
        <div class="layui-card-header">
            <?=$title?>
        </div>
        <div class="layui-card-body">
          <div class="wrapper-md control" id="add">
	         <div class="panel panel-default">
				<div class="panel-body">
					<form class="form-horizontal devform" id="form-web">
					    
						<div class="layui-form-item">
							<label class="layui-form-label">公告</label>
								<div class="layui-input-block" >
									<textarea type="text" name="notice" class="layui-textarea"  rows="5"><?=$conf['notice']?></textarea>
							</div>
						</div>
						
				  	    <div class="layui-input-block">
				  	    	<input type="button" @click="add" value="立即修改" class="layui-btn"/>
				  	    </div>
			        </form>
		        </div>
	        </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once("footer.php");?>

<script>
new Vue({
	el:"#add",
	data:{

	},
	methods:{
	    add:function(){
	        var loading=layer.load();
	    	this.$http.post("/apisub.php?act=webset",{data:$("#form-web").serialize()},{emulateJSON:true}).then(function(data){
	    		layer.close(loading);
	    		if(data.data.code==1){
	    			layer.alert(data.data.msg,{icon:1,title:"温馨提示"},function(){setTimeout(function(){window.location.href=""});});
	    		}else{
	    			layer.alert(data.data.msg,{icon:2,title:"温馨提示"});
	    		}
	    	});
	    }   
	},
	mounted(){
		//this.getclass();		
	}
	
	
});
</script>