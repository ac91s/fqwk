<?php
$title='QQ登录（绑定QQ请使用手机端绑定信息，电脑端不跳转！！）';
require_once('header.php');
?>

<div class="layui-fluid" id="LAY-component-grid-mobile-pc">
  <div class="layui-row layui-col-space10">
    <div class="layui-col-xs12 layui-col-md12">
      <!-- 填充内容 -->
      <div class="layui-card">
        <div class="layui-card-header">
            <?=$title?>
        </div>
        
        <div class="layui-card-body">
          <div class="wrapper-md control" id="add">
	         <div class="panel panel-default">
				<div class="panel-body">
					<form class="form-horizontal devform" id="form-web">
       
                  <div class="avatar-divider"></div>
							<label class="layui-form-label">QQ名称</label>
								<div class="layui-input-block">
									<input type="text" class="layui-input" name="sitename" value="<?=$userrow['nickname']==null? '您还未绑定': $userrow['nickname']?>" required>
							</div>
						</div>
<br>
						<div class="layui-form-item">
							<label class="layui-form-label">QQID</label>
								<div class="layui-input-block">
									<input type="text" class="layui-input" name="keywords" value="<?=$userrow['qq_openid']==null? '您还未绑定': $userrow['qq_openid']?>" required>
							</div>
						</div>
						
						 <div class="layui-input-block">
						     <?php
                  if(empty($userrow['qq_openid'])) {
                  ?>
                  <button type="button" id="connect_qq" class="layui-btn">点击绑定</button>
                  <?php
                  }
                  ?>
				  	    	
				  	    </div>
                  
                  
                
    <!--End 页面主要内容-->
  </div>
</div>
<script>
    $('#connect_qq').click(function() {
        var ii = layer.load(0, {
            shade: [0.1, '#fff']
        });
        $.ajax({
            type: "POST",
            url: "../qq_login.php",
            data: {"type":'qq'},
            dataType: 'json',
            success: function(data) {
                layer.close(ii);
                if (data.code == 1) {
                    window.location.href = data.url;
                } else {
                    layer.alert(data.msg, {
                        icon: 7
                    });
                }
            }
        });
    });
</script>
<?php require_once("footer.php");?>